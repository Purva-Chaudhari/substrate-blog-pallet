A crate that hosts a common definitions that are relevant for the pallet-contracts.

License: Apache-2.0